const statusEl = document.getElementById("serverStatus");
const camera = document.getElementById("camera");
const cameraError = document.getElementById("cameraError");
const form = document.getElementById("uploadForm");
const result = document.getElementById("uploadResult");
const portSelect = document.getElementById("serialPort");
const portStatus = document.getElementById("portStatus");
const refreshPortsButton = document.getElementById("refreshPorts");

async function refreshPorts() {
  const previous = portSelect.value;
  portSelect.replaceChildren(new Option("Загрузка списка портов…", ""));
  portStatus.textContent = "Ищем COM-порты на компьютере лаборатории…";
  refreshPortsButton.disabled = true;
  try {
    const response = await fetch("/api/ports", { cache: "no-store" });
    const body = await response.json();
    if (!response.ok || !body.success) throw new Error(body.message || "Ошибка получения портов");
    portSelect.replaceChildren();
    if (!body.ports.length) {
      portSelect.add(new Option("COM-порты не найдены", ""));
      portStatus.textContent = "Arduino не обнаружена. Подключите плату и нажмите «Обновить».";
      return;
    }
    portSelect.add(new Option("Выберите порт…", ""));
    for (const item of body.ports) {
      const option = new Option(`${item.port} — ${item.name}`, item.port);
      portSelect.add(option);
    }
    if (body.ports.some(item => item.port === previous)) portSelect.value = previous;
    else if (body.ports.length === 1) portSelect.value = body.ports[0].port;
    portStatus.textContent = `Найдено портов: ${body.ports.length}. Выберите порт, к которому подключена Arduino Uno.`;
  } catch (error) {
    portSelect.replaceChildren(new Option("Не удалось получить список портов", ""));
    portStatus.textContent = error.message || "Ошибка получения списка COM-портов.";
  } finally {
    refreshPortsButton.disabled = false;
  }
}

refreshPortsButton.addEventListener("click", refreshPorts);
refreshPorts();

fetch("/api/status")
  .then(r => { if (!r.ok) throw new Error(); return r.json(); })
  .then(data => { statusEl.textContent = `${data.message}. Камера: ${data.cameraName}`; })
  .catch(() => { statusEl.textContent = "Не удалось получить статус сервера"; });

camera.addEventListener("error", () => { cameraError.hidden = false; });
camera.addEventListener("load", () => { cameraError.hidden = true; });

form.addEventListener("submit", async event => {
  event.preventDefault();
  const input = document.getElementById("firmware");
  if (!portSelect.value) { result.textContent = "Сначала выберите COM-порт Arduino."; return; }
  if (!input.files.length) { result.textContent = "Сначала выберите файл .hex."; return; }
  const data = new FormData();
  data.append("firmware", input.files[0]);
  data.append("port", portSelect.value);
  result.textContent = "Прошивка выполняется. Не отключайте Arduino…";
  form.querySelector("button[type=submit]").disabled = true;
  try {
    const response = await fetch("/api/flash", { method: "POST", body: data });
    const body = await response.json();
    result.textContent = body.success
      ? `${body.message} Размер файла: ${body.size} байт.`
      : `Ошибка: ${body.message}`;
  } catch { result.textContent = "Не удалось связаться с сервером."; }
  finally { form.querySelector("button[type=submit]").disabled = false; }
});
