const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const { spawn } = require("child_process");
const config = require("./config");

let flashInProgress = false;

const app = express();
const uploadDir = path.join(__dirname, "uploads");
const logsDir = path.join(__dirname, "logs");
fs.mkdirSync(uploadDir, { recursive: true });
fs.mkdirSync(logsDir, { recursive: true });

function getSerialPorts() {
  return new Promise((resolve, reject) => {
    const ps = `Get-CimInstance Win32_SerialPort | Select-Object DeviceID,Name | ConvertTo-Json -Compress`;
    const child = spawn("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps], { windowsHide: true });
    let stdout = "";
    let stderr = "";
    child.stdout.setEncoding("utf8");
    child.stderr.setEncoding("utf8");
    child.stdout.on("data", chunk => { stdout += chunk; });
    child.stderr.on("data", chunk => { stderr += chunk; });
    child.on("error", reject);
    child.on("close", code => {
      if (code !== 0) return reject(new Error(stderr || "Не удалось получить список COM-портов"));
      if (!stdout.trim()) return resolve([]);
      try {
        const parsed = JSON.parse(stdout.trim());
        const rows = Array.isArray(parsed) ? parsed : [parsed];
        resolve(rows.filter(row => /^COM\d+$/i.test(String(row.DeviceID || "")))
          .map(row => ({ port: String(row.DeviceID).toUpperCase(), name: String(row.Name || row.DeviceID) }))
          .sort((a, b) => Number(a.port.slice(3)) - Number(b.port.slice(3))));
      } catch (error) { reject(new Error("Не удалось разобрать список COM-портов: " + error.message)); }
    });
  });
}


function findAvrdude() {
  const a = config.arduino;
  const candidates = [];
  if (a.avrdudePath) candidates.push({ exe: a.avrdudePath, conf: a.avrdudeConfigPath });
  const programFiles = [process.env.ProgramFiles, process.env["ProgramFiles(x86)"], process.env.LOCALAPPDATA]
    .filter(Boolean);
  for (const root of programFiles) {
    candidates.push({ exe: path.join(root, "Arduino", "hardware", "tools", "avr", "bin", "avrdude.exe"), conf: path.join(root, "Arduino", "hardware", "tools", "avr", "etc", "avrdude.conf") });
    candidates.push({ exe: path.join(root, "Arduino IDE", "resources", "app", "lib", "backend", "resources", "avrdude", "windows", "avrdude.exe"), conf: path.join(root, "Arduino IDE", "resources", "app", "lib", "backend", "resources", "avrdude", "windows", "avrdude.conf") });
  }
  const local = process.env.LOCALAPPDATA;
  if (local) {
    const toolsRoot = path.join(local, "Arduino15", "packages", "arduino", "tools", "avrdude");
    try {
      for (const version of fs.readdirSync(toolsRoot).sort().reverse()) {
        const root = path.join(toolsRoot, version);
        candidates.push({ exe: path.join(root, "bin", "avrdude.exe"), conf: path.join(root, "etc", "avrdude.conf") });
      }
    } catch (_) { /* Arduino IDE may not be installed */ }
  }
  for (const item of candidates) {
    if (item.exe && fs.existsSync(item.exe)) {
      let conf = item.conf;
      if (!conf || !fs.existsSync(conf)) {
        const beside = path.join(path.dirname(item.exe), "..", "etc", "avrdude.conf");
        if (fs.existsSync(beside)) conf = path.resolve(beside);
      }
      if (conf && fs.existsSync(conf)) return { exe: item.exe, conf };
    }
  }
  return null;
}

function runAvrdude(hexPath, port, toolchain) {
  return new Promise((resolve, reject) => {
    const args = ["-C", toolchain.conf, "-v", "-p", config.arduino.mcu, "-c", config.arduino.programmer,
      "-P", port, "-b", String(config.arduino.baudRate), "-D", "-U", `flash:w:${hexPath}:i`];
    const child = spawn(toolchain.exe, args, { windowsHide: true, shell: false });
    let output = "";
    let settled = false;
    const finish = (err, value) => { if (settled) return; settled = true; clearTimeout(timer); err ? reject(err) : resolve(value); };
    const collect = chunk => { output = (output + chunk.toString()).slice(-12000); };
    child.stdout.on("data", collect);
    child.stderr.on("data", collect);
    child.on("error", err => finish(new Error(`Не удалось запустить avrdude: ${err.message}`)));
    child.on("close", code => code === 0 ? finish(null, output) : finish(new Error(`avrdude завершился с кодом ${code}.\n${output}`)));
    const timer = setTimeout(() => { child.kill(); finish(new Error(`Превышено время прошивки (${Math.round(config.arduino.flashTimeoutMs / 1000)} с).\n${output}`)); }, config.arduino.flashTimeoutMs);
  });
}

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadDir),
    filename: (_req, _file, cb) => cb(null, `${Date.now()}-${crypto.randomUUID()}.hex`)
  }),
  limits: { fileSize: config.maxUploadBytes, files: 1 },
  fileFilter: (_req, file, cb) => path.extname(file.originalname).toLowerCase() === ".hex"
    ? cb(null, true) : cb(new Error("Разрешены только файлы Intel HEX с расширением .hex"))
});

app.disable("x-powered-by");
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/status", (_req, res) => res.json({
  online: true, cameraConfigured: Boolean(config.cameraName),
  cameraName: config.cameraName, message: "Сервер лаборатории работает",
  maxUploadBytes: config.maxUploadBytes, flashInProgress, avrdudeAvailable: Boolean(findAvrdude()), baudRate: config.arduino.baudRate
}));

app.get("/api/ports", async (_req, res) => {
  try {
    res.json({ success: true, ports: await getSerialPorts() });
  } catch (error) {
    console.error("Ошибка поиска COM-портов:", error.message);
    res.status(500).json({ success: false, message: "Не удалось получить COM-порты. Проверьте, что сервер запущен в Windows." });
  }
});

app.post("/api/flash", (req, res, next) => {
  if (flashInProgress) return res.status(409).json({ success: false, message: "Прошивка уже выполняется. Дождитесь её завершения." });
  next();
}, upload.single("firmware"), async (req, res) => {
  if (!req.file) return res.status(400).json({ success: false, message: "Выберите файл .hex" });
  const selectedPort = String(req.body.port || "").toUpperCase();
  const cleanup = () => fs.unlink(req.file.path, () => {});
  if (!/^COM\d+$/.test(selectedPort)) { cleanup(); return res.status(400).json({ success: false, message: "Выберите COM-порт перед прошивкой." }); }
  let availablePorts;
  try { availablePorts = await getSerialPorts(); }
  catch (_) { cleanup(); return res.status(500).json({ success: false, message: "Не удалось проверить выбранный COM-порт." }); }
  if (!availablePorts.some(item => item.port === selectedPort)) { cleanup(); return res.status(400).json({ success: false, message: `Порт ${selectedPort} не найден. Обновите список портов.` }); }
  const toolchain = findAvrdude();
  if (!toolchain) {
    cleanup();
    return res.status(500).json({ success: false, message: "Не найден avrdude. Установите Arduino IDE и проверьте пути avrdudePath/avrdudeConfigPath в config.js." });
  }
  // Проверяем базовую структуру Intel HEX до запуска программатора.
  try {
    const hex = fs.readFileSync(req.file.path, "utf8");
    const lines = hex.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
    if (!lines.length || lines.some(line => !/^:[0-9A-Fa-f]+$/.test(line) || line.length < 11) || !lines.some(line => line.slice(7, 9).toUpperCase() === "01")) {
      cleanup();
      return res.status(400).json({ success: false, message: "Файл не похож на корректный Intel HEX: проверьте, что выбран скетч Arduino в формате .hex." });
    }
  } catch (_) { cleanup(); return res.status(400).json({ success: false, message: "Не удалось прочитать HEX-файл." }); }
  flashInProgress = true;
  const entry = { time: new Date().toISOString(), selectedPort, originalName: path.basename(req.file.originalname).slice(0, 180), size: req.file.size, action: "flash_started" };
  fs.appendFileSync(path.join(logsDir, "uploads.jsonl"), JSON.stringify(entry) + "\n", "utf8");
  console.log(`Начата прошивка ${entry.originalName} через ${selectedPort}`);
  try {
    const output = await runAvrdude(req.file.path, selectedPort, toolchain);
    const done = { ...entry, time: new Date().toISOString(), action: "flash_success" };
    fs.appendFileSync(path.join(logsDir, "uploads.jsonl"), JSON.stringify(done) + "\n", "utf8");
    console.log(`Прошивка завершена успешно: ${selectedPort}`);
    res.json({ success: true, message: `Прошивка успешно записана в Arduino через ${selectedPort}.`, port: selectedPort, size: req.file.size, output: output.slice(-5000) });
  } catch (error) {
    const failed = { ...entry, time: new Date().toISOString(), action: "flash_failed", error: error.message.slice(0, 3000) };
    fs.appendFileSync(path.join(logsDir, "uploads.jsonl"), JSON.stringify(failed) + "\n", "utf8");
    console.error(`Ошибка прошивки ${selectedPort}:`, error.message);
    res.status(500).json({ success: false, message: error.message.slice(0, 5000) });
  } finally {
    flashInProgress = false;
    cleanup();
  }
});

app.get("/camera", (req, res) => {
  const boundary = "ffmpeg";
  const args = [
    "-hide_banner", "-loglevel", "warning",
    "-f", "dshow", "-rtbufsize", config.inputBuffer,
    "-i", `video=${config.cameraName}`,
    "-an", "-vf", `scale=${config.outputWidth}:-1,fps=${config.frameRate}`,
    "-c:v", "mjpeg", "-q:v", String(config.jpegQuality),
    "-f", "mpjpeg", "-boundary_tag", boundary, "pipe:1"
  ];
  let ffmpeg;
  try {
    ffmpeg = spawn(config.ffmpegPath, args, { windowsHide: true });
  } catch (error) {
    console.error("Не удалось запустить FFmpeg:", error.message);
    return res.status(500).send("Не удалось запустить FFmpeg. Проверьте ffmpegPath в config.js.");
  }
  res.status(200);
  res.setHeader("Content-Type", `multipart/x-mixed-replace; boundary=${boundary}`);
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.setHeader("Pragma", "no-cache");
  res.setHeader("X-Content-Type-Options", "nosniff");
  let stderrText = "";
  ffmpeg.stdout.pipe(res);
  ffmpeg.stderr.on("data", chunk => { stderrText = (stderrText + chunk.toString()).slice(-4000); });
  ffmpeg.on("error", error => {
    console.error("Ошибка запуска FFmpeg:", error.message);
    if (!res.headersSent) res.status(500).end("Ошибка запуска FFmpeg."); else res.end();
  });
  ffmpeg.on("close", code => {
    if (code !== 0 && !res.destroyed) console.error(`FFmpeg завершился с кодом ${code}: ${stderrText}`);
  });
  const stop = () => {
    if (ffmpeg && ffmpeg.exitCode === null && !ffmpeg.killed) ffmpeg.kill();
  };
  req.on("close", stop);
  res.on("close", stop);
});

app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError) {
    const msg = err.code === "LIMIT_FILE_SIZE"
      ? `Файл слишком большой. Максимум: ${Math.round(config.maxUploadBytes / 1048576)} МБ.`
      : "Ошибка загрузки файла.";
    return res.status(400).json({ success: false, message: msg });
  }
  res.status(400).json({ success: false, message: err.message || "Ошибка обработки запроса." });
});

app.listen(config.port, "0.0.0.0", () => {
  console.log(`Веб-сервер: http://localhost:${config.port}`);
  console.log(`Видеопоток: http://localhost:${config.port}/camera`);
  console.log(`Камера: ${config.cameraName}`);
  console.log(`FFmpeg: ${config.ffmpegPath}`);
  console.log(`Arduino Uno R3: ATmega328P, скорость загрузки ${config.arduino.baudRate}.`);
  console.log(`AVRDUDE: ${findAvrdude() ? findAvrdude().exe : "не найден — установите Arduino IDE или задайте пути в config.js"}`);
  console.log("Используйте только в доверенной сети Radmin VPN; не публикуйте порт в интернете.");
});
